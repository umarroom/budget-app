import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _pendingCount = prefs.getInt('ff_pendingCount') ?? _pendingCount;
    });
    _safeInit(() {
      _totalMonthAmount =
          prefs.getDouble('ff_totalMonthAmount') ?? _totalMonthAmount;
    });
    _safeInit(() {
      _smsSenders = prefs.getStringList('ff_smsSenders') ?? _smsSenders;
    });
    _safeInit(() {
      _isDbInitialized =
          prefs.getBool('ff_isDbInitialized') ?? _isDbInitialized;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  int _pendingCount = 0;
  int get pendingCount => _pendingCount;
  set pendingCount(int value) {
    _pendingCount = value;
    prefs.setInt('ff_pendingCount', value);
  }

  double _totalMonthAmount = 0.0;
  double get totalMonthAmount => _totalMonthAmount;
  set totalMonthAmount(double value) {
    _totalMonthAmount = value;
    prefs.setDouble('ff_totalMonthAmount', value);
  }

  List<String> _smsSenders = [];
  List<String> get smsSenders => _smsSenders;
  set smsSenders(List<String> value) {
    _smsSenders = value;
    prefs.setStringList('ff_smsSenders', value);
  }

  void addToSmsSenders(String value) {
    smsSenders.add(value);
    prefs.setStringList('ff_smsSenders', _smsSenders);
  }

  void removeFromSmsSenders(String value) {
    smsSenders.remove(value);
    prefs.setStringList('ff_smsSenders', _smsSenders);
  }

  void removeAtIndexFromSmsSenders(int index) {
    smsSenders.removeAt(index);
    prefs.setStringList('ff_smsSenders', _smsSenders);
  }

  void updateSmsSendersAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    smsSenders[index] = updateFn(_smsSenders[index]);
    prefs.setStringList('ff_smsSenders', _smsSenders);
  }

  void insertAtIndexInSmsSenders(int index, String value) {
    smsSenders.insert(index, value);
    prefs.setStringList('ff_smsSenders', _smsSenders);
  }

  bool _isDbInitialized = false;
  bool get isDbInitialized => _isDbInitialized;
  set isDbInitialized(bool value) {
    _isDbInitialized = value;
    prefs.setBool('ff_isDbInitialized', value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
