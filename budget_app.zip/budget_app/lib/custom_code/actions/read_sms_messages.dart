// Automatic FlutterFlow imports
import '/actions/actions.dart' as action_blocks;
import '/app_events/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter_sms_inbox/flutter_sms_inbox.dart';
import 'package:permission_handler/permission_handler.dart';

Future<List<dynamic>> readSmsMessages(
  List<String> senders,
) async {
  final status = await Permission.sms.request();
  if (!status.isGranted) return [];

  final query = SmsQuery();
  final allSms = await query.getAllSms;

  final List<Map<String, dynamic>> result = [];

  for (final sms in allSms.take(100)) {
    final match = senders.any(
        (s) => sms.address?.toLowerCase().contains(s.toLowerCase()) ?? false);

    if (!match) continue;

    result.add({
      'id': sms.id.toString(),
      'sender': sms.address ?? '',
      'body': sms.body ?? '',
      'date': sms.date?.toIso8601String() ?? '',
    });
  }

  return result;
}
