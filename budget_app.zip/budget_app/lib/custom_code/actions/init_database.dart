// Automatic FlutterFlow imports
import '/actions/actions.dart' as action_blocks;
import '/app_events/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

Future initDatabase() async {
  final dbPath = await getDatabasesPath();
  final db = await openDatabase(
    join(dbPath, 'budget.db'),
    version: 1,
    onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE pending_transactions (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          raw_sms     TEXT NOT NULL,
          sender      TEXT,
          amount      REAL,
          currency    TEXT DEFAULT "SAR",
          type        TEXT DEFAULT "unknown",
          merchant    TEXT,
          confidence  REAL DEFAULT 0.0,
          status      TEXT DEFAULT "pending",
          sms_hash    TEXT UNIQUE,
          created_at  TEXT DEFAULT (datetime("now"))
        )
      ''');

      await db.execute('''
        CREATE TABLE budget_records (
          id             INTEGER PRIMARY KEY AUTOINCREMENT,
          date           TEXT,
          amount         REAL,
          currency       TEXT DEFAULT "SAR",
          type           TEXT,
          classification TEXT,
          responsible    TEXT,
          description    TEXT,
          payment_method TEXT,
          notes          TEXT,
          source         TEXT DEFAULT "manual",
          sender         TEXT,
          raw_sms        TEXT,
          confidence     REAL,
          created_at     TEXT DEFAULT (datetime("now")),
          updated_at     TEXT DEFAULT (datetime("now"))
        )
      ''');

      await db.execute('''
        CREATE TABLE sms_senders (
          id      INTEGER PRIMARY KEY AUTOINCREMENT,
          name    TEXT NOT NULL,
          enabled INTEGER DEFAULT 1
        )
      ''');

      final senders = [
        'الأهلي',
        'ALINMA',
        'الراجحي',
        'RAJHI',
        'SNB-AlAhli',
        'الرياض',
        'BSF',
        'SABB',
        'STC Pay',
        'STC Bank',
        'urpay',
        'مدى'
      ];
      for (final s in senders) {
        await db.insert('sms_senders', {'name': s, 'enabled': 1});
      }
    },
  );
  await db.close();
}
