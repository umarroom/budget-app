// Automatic FlutterFlow imports
import '/actions/actions.dart' as action_blocks;
import '/app_events/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

Future<dynamic> extractTransaction(
  String smsBody,
  String smsSender,
) async {
  final body = smsBody;
  final result = <String, dynamic>{
    'raw_sms': body,
    'sender': smsSender,
    'amount': null,
    'currency': 'SAR',
    'merchant': null,
    'type': 'unknown',
    'confidence': 0.0,
    'is_financial': false,
  };

  // ── تصفية غير المالية ──
  final nonFinancial = [
    RegExp(r'\b(OTP|رمز|password|تحقق|verification)\b', caseSensitive: false),
    RegExp(r'\b(تسجيل دخول|login)\b', caseSensitive: false),
    RegExp(r'\b(عرض|offer|تخفيض|discount)\b', caseSensitive: false),
    RegExp(r'\b(فشل|failed|مرفوض)\b', caseSensitive: false),
  ];

  for (final p in nonFinancial) {
    if (p.hasMatch(body)) return result;
  }

  int points = 0;

  // ── استخراج المبلغ ──
  final amountPatterns = [
    RegExp(r'(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)\s*(?:ريال|SAR|SR)',
        caseSensitive: false),
    RegExp(r'(?:ريال|SAR|SR)\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)',
        caseSensitive: false),
    RegExp(r'(?:مبلغ|amount|بمبلغ)[:\s]*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)',
        caseSensitive: false),
  ];

  for (final p in amountPatterns) {
    final m = p.firstMatch(body);
    if (m != null) {
      result['amount'] = double.tryParse(m.group(1)?.replaceAll(',', '') ?? '');
      points += 40;
      break;
    }
  }

  // ── نوع العملية ──
  if (RegExp(r'\b(شراء|purchase|سحب|withdrawal)\b', caseSensitive: false)
      .hasMatch(body)) {
    result['type'] = 'expense';
    points += 20;
  } else if (RegExp(r'\b(إيداع|deposit|راتب|salary)\b', caseSensitive: false)
      .hasMatch(body)) {
    result['type'] = 'income';
    points += 20;
  } else if (RegExp(r'\b(تحويل|transfer)\b', caseSensitive: false)
      .hasMatch(body)) {
    result['type'] = 'transfer';
    points += 20;
  } else if (RegExp(r'\b(استرداد|refund)\b', caseSensitive: false)
      .hasMatch(body)) {
    result['type'] = 'refund';
    points += 20;
  }

  // ── استخراج التاجر ──
  final merchantMatch = RegExp(
    r'(?:لدى|at|merchant)[:\s]+([^\n\r،,\.]{3,40})',
    caseSensitive: false,
  ).firstMatch(body);

  if (merchantMatch != null) {
    result['merchant'] = merchantMatch.group(1)?.trim();
    points += 20;
  }

  // ── النتيجة النهائية ──
  result['confidence'] = (points / 80).clamp(0.0, 1.0);
  result['is_financial'] = result['amount'] != null;

  // ── حفظ في قاعدة البيانات ──
  if (result['is_financial'] == true) {
    final dbPath = await getDatabasesPath();
    final db = await openDatabase(join(dbPath, 'budget.db'));
    final hash = body.hashCode.toString();

    await db.insert(
      'pending_transactions',
      {
        'raw_sms': body,
        'sender': smsSender,
        'amount': result['amount'],
        'currency': result['currency'],
        'type': result['type'],
        'merchant': result['merchant'],
        'confidence': result['confidence'],
        'sms_hash': hash,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
    await db.close();
  }

  return result;
}
