// Automatic FlutterFlow imports
import '/actions/actions.dart' as action_blocks;
import '/app_events/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

Future saveExpense(
  String date,
  double amount,
  String classification,
  String responsible,
  String description,
  String notes,
) async {
  final dbPath = await getDatabasesPath();
  final db = await openDatabase(join(dbPath, 'budget.db'));

  await db.insert('budget_records', {
    'date': date,
    'amount': amount,
    'classification': classification,
    'responsible': responsible,
    'description': description,
    'notes': notes,
  });

  await db.close();
}
