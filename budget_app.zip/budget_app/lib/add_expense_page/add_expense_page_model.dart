import '/flutter_flow/flutter_flow_calendar.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import 'add_expense_page_widget.dart' show AddExpensePageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AddExpensePageModel extends FlutterFlowModel<AddExpensePageWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Date widget.
  DateTimeRange? dateSelectedDay;
  // State field(s) for Amount widget.
  FocusNode? amountFocusNode;
  TextEditingController? amountTextController;
  String? Function(BuildContext, String?)? amountTextControllerValidator;
  // State field(s) for Classification widget.
  String? classificationValue;
  FormFieldController<String>? classificationValueController;
  // State field(s) for Responsible widget.
  String? responsibleValue;
  FormFieldController<String>? responsibleValueController;
  // State field(s) for Description widget.
  FocusNode? descriptionFocusNode;
  TextEditingController? descriptionTextController;
  String? Function(BuildContext, String?)? descriptionTextControllerValidator;
  // State field(s) for NotesOptional widget.
  FocusNode? notesOptionalFocusNode;
  TextEditingController? notesOptionalTextController;
  String? Function(BuildContext, String?)? notesOptionalTextControllerValidator;

  @override
  void initState(BuildContext context) {
    dateSelectedDay = DateTimeRange(
      start: DateTime.now().startOfDay,
      end: DateTime.now().endOfDay,
    );
  }

  @override
  void dispose() {
    amountFocusNode?.dispose();
    amountTextController?.dispose();

    descriptionFocusNode?.dispose();
    descriptionTextController?.dispose();

    notesOptionalFocusNode?.dispose();
    notesOptionalTextController?.dispose();
  }
}
