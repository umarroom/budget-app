import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import 'pending_page_widget.dart' show PendingPageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PendingPageModel extends FlutterFlowModel<PendingPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Custom Action - readSmsMessages] action in PendingPage widget.
  List<dynamic>? smsResults;
  // Stores action output result for [Custom Action - extractTransaction] action in PendingPage widget.
  dynamic? transactionResult;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
